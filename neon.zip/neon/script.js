$(document).ready(function() {
  $(".girlsgirlsgirls").mouseenter(function() {
    $(".dont_worry").addClass("show");
  });

  $(".girlsgirlsgirls").mouseleave(function() {
    $(".girlsgirlsgirls").addClass("hide");
  });

  $(".dont_worry").mouseenter(function() {
    $(".if_youre_sad").addClass("show");
  });

  $(".dont_worry").mouseleave(function() {
    $(".dont_worry").addClass("hide");
  });

  $(".if_youre_sad").mouseenter(function() {
    $(".feminist").addClass("show");
  });

  $(".if_youre_sad").mouseleave(function() {
    $(".if_youre_sad").addClass("hide");
  });

  $(".if_youre_sad").mouseenter(function() {
    $(".feminist").addClass("show");
  });

    $(".feminist").mouseleave(function() {
    $(".feminist").addClass("hide");
  });

  $(".feminist").mouseenter(function() {
    $(".who_run_the_world").addClass("show");
  });

    $(".who_run_the_world").mouseleave(function() {
    $(".who_run_the_world").addClass("hide");
  });


  $(".who_run_the_world").mouseenter(function() {
    $(".what_if").addClass("show");
  });


    $(".what_if").mouseleave(function() {
    $(".what_if").addClass("hide");
  });


 	$(".what_if").mouseenter(function() {
    $(".do_fun_shit").addClass("show");
  });


    $(".do_fun_shit").mouseleave(function() {
    $(".do_fun_shit").addClass("hide");
  });


 	$(".do_fun_shit").mouseenter(function() {
    $(".and_justice_for_all").addClass("show");
  });


    $(".and_justice_for_all").mouseleave(function() {
    $(".and_justice_for_all").addClass("hide");
  });


    $(".and_justice_for_all").mouseenter(function() {
    $(".more_dior_less_war").addClass("show");
  });

    $(".more_dior_less_war").mouseleave(function() {
    $(".more_dior_less_war").addClass("hide");
});

    $(".more_dior_less_war").mouseenter(function() {
    $(".by_popular_demand").addClass("show");
  });

    $(".by_popular_demand").mouseleave(function() {
    $(".by_popular_demand").addClass("hide");
});

    $(".by_popular_demand").mouseenter(function() {
    $(".she_is").addClass("show");
  });

    $(".she_is").mouseleave(function() {
    $(".she_is").addClass("hide");
});

    $(".she_is").mouseenter(function() {
    $(".shes_american").addClass("show");
  });

    $(".shes_american").mouseleave(function() {
    $(".shes_american").addClass("hide");
});
    $(".shes_american").mouseenter(function() {
    $(".badass").addClass("show");
  });

    $(".badass").mouseleave(function() {
    $(".badass").addClass("hide");
});

    $(".badass").mouseenter(function() {
    $(".girlboss").addClass("show");
  });

});